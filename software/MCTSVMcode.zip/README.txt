Xijiong Xie, Shiliang Sun. Multitask centroid twin support vector machines, Neurocomputing.
1.This code can be a running on monk dataset. I don't write as funcional form  so it is limit to three tasks. Researchers can refer to this code and apply it in more tasks.
It is difficult to choose best parameters and you can use a grid search strategy to select best parameters (C,R,h,l).
2.cvx software package can be downloaded from http://cvxr.com/cvx/download/.

Xijiong Xie