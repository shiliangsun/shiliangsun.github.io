%Xijiong Xie MCTSVM
load task1.mat
load task2.mat
load task3.mat
for R=0:1:20 
    for l=-10:0.5:10 
h=0.01;%choose the parameters of CTSVM
R=2^R;
l=2^l;
C=R;
o=6;%the dimension of the dataset
r=7;%dimension+1
c=80; %the number of the train dataset
m11=0;
m12=0;
q1=1;
p1=1;
%choose the dataset of the first task
for i=1:c
    if(task1(i,r)==1)
        m11=m11+1;
    end
end
m12=c-m11;
A1=zeros(m11,o);
B1=zeros(m12,o);
for i=1:c
    if(task1(i,r)==1)
        for j=1:o
        A1(q1,j)=task1(i,j);
        end
        q1=q1+1;
    else
            for j=1:o
        B1(p1,j)=task1(i,j);
            end
            p1=p1+1;
    end
end
e11=ones(m11+1,1);
e12=ones(m12+1,1);
K=zeros(1,o);
for j=1:o
    for i=1:m11
    K(1,j)=A1(i,j)+K(1,j);
    end
    K(1,j)=h*K(1,j)/m11;
end
U=zeros(1,o);
for j=1:o
    for i=1:m12
    U(1,j)=B1(i,j)+U(1,j);
    end
   U(1,j)=h*U(1,j)/m12;
end
A11=[A1;K];
A11=[A11,e11];
B11=[B1;U];
B11=[B11,e12];
m12=m12+1;
m11=m11+1;

%choose the dataset of the second task
m21=0;
m22=0;
q=1;
p=1;
for i=1:c
    if(task2(i,r)==1)
        m21=m21+1;
    end
end
m22=c-m21;
A2=zeros(m21,o);
B2=zeros(m22,o);
for i=1:c
    if(task2(i,r)==1)
        for j=1:o
        A2(q,j)=task2(i,j);
        end
        q=q+1;
    else
            for j=1:o
        B2(p,j)=task2(i,j);
            end
            p=p+1;
    end
end
e21=ones(m21+1,1);
e22=ones(m22+1,1);
K=zeros(1,o);
for j=1:o
    for i=1:m21
    K(1,j)=A2(i,j)+K(1,j);
    end
    K(1,j)=h*K(1,j)/m21;
end
U=zeros(1,o);
for j=1:o
    for i=1:m22
    U(1,j)=B2(i,j)+U(1,j);
    end
    U(1,j)=h*U(1,j)/m22;
end
A22=[A2;K];
A22=[A22,e21];
B22=[B2;U];
B22=[B22,e22];
m21=m21+1;
m22=m22+1;

%choose the dataset of the third task
m31=0;
m32=0;
q=1;
p=1;
for i=1:c
    if(task3(i,r)==1)
        m31=m31+1;
    end
end
m32=c-m31;
A3=zeros(m31,o);
B3=zeros(m32,o);
for i=1:c
    if(task3(i,r)==1)
        for j=1:o
        A3(q,j)=task3(i,j);
        end
        q=q+1;
    else
            for j=1:o
        B3(p,j)=task3(i,j);
            end
            p=p+1;
    end
end
e31=ones(m31+1,1);
e32=ones(m32+1,1);
K=zeros(1,o);
for j=1:o
    for i=1:m31
    K(1,j)=A3(i,j)+K(1,j);
    end
    K(1,j)=h*K(1,j)/m31;
end
U=zeros(1,o);
for j=1:o
    for i=1:m32
    U(1,j)=B3(i,j)+U(1,j);
    end
    U(1,j)=h*U(1,j)/m32;
end
A33=[A3;K];
A33=[A33,e31];
B33=[B3;U];
B33=[B33,e32];
m31=m31+1;
m32=m32+1;

A=[A1;A2;A3];
B=[B1;B2;B3];
[cc,dd]=size(A);
[ff,gg]=size(B);
e1=ones(ff+3,1);
c1=l*ones(ff+3,1);
H=zeros(ff+3,ff+3);
for j=1:o
    for i=1:cc
    K(1,j)=A(i,j)+K(1,j);
    end
    K(1,j)=h*K(1,j)/cc;
end
U=zeros(1,o);
for j=1:o
    for i=1:ff
    U(1,j)=B(i,j)+U(1,j);
    end
    U(1,j)=h*U(1,j)/ff;
end
e6=ones(cc+1,1);
e7=ones(ff+1,1);
A=[A;K];
B=[B;U];
A=[A,e6];
B=[B,e7];
M=[A11;A22;A33];
N=[B11;B22;B33];%Readers can extend to nolinear easily by using calckernel(X,[A;B]) referring to the paper. 



s=0.0001*eye(7,7);
h1=B11*inv(A11'*A11+s)*B11'/R;
h2=B22*inv(A22'*A22+s)*B22'/R;
h3=B33*inv(A33'*A33+s)*B33'/R;
for i=1:m12
    for j=1:m12
    H(i,j)=h1(i,j);
    end
end
for i=1:m22
    for j=1:m22
        H(m12+i,m12+j)=h2(i,j);
    end
end
for i=1:m32
    for j=1:m32
        H(m12+m22+i,m12+m22+j)=h3(i,j);
    end
end
G=N*inv(A'*A+s)*N';
Y=G+H;
cvx_begin  %solving the first quadratic optimization
variable x(ff+3,1);
minimize(1/2*x'*Y*x-e1'*x);
subject to
x>=0;
x<=c1;
cvx_end
V=zeros(cc+3,cc+3);
v1=A11*inv(B11'*B11+s)*A11'/C;
v2=A22*inv(B22'*B22+s)*A22'/C;
v3=A33*inv(B33'*B33+s)*A33'/C;
for i=1:m11
    for j=1:m11
    V(i,j)=v1(i,j);
    end
end
for i=1:m21
    for j=1:m21
        V(m11+i,m11+j)=v2(i,j);
    end
end
for i=1:m31
    for j=1:m31
        V(m11+m21+i,m11+m21+j)=v3(i,j);
    end
end
F=M*inv(B'*B+s)*M';
M=F+V;
e2=ones(cc+3,1);
c2=l*ones(cc+3,1);
cvx_begin  %solving the second quadratic optimization
variable y(cc+3,1);
minimize(1/2*y'*M*y-e2'*y);
subject to
y>=0;
y<=c2;
cvx_end
a1=x(1:m12,:);
a2=x(m12+1:m12+m22,:);
a3=x(m12+m22+1:m12+m22+m32,:);
r1=y(1:m11,:);
r2=y(m11+1:m11+m21,:);
r3=y(m11+m21+1:m11+m21+m31,:);
w=-inv(A'*A+s)*(B11'*a1+B22'*a2+B33'*a3);
w1=-1/R*inv(A11'*A11+s)*B11'*a1;
w2=-1/R*inv(A22'*A22+s)*B22'*a2;
w3=-1/R*inv(A33'*A33+s)*B33'*a3;
W1=w+w1;
W2=w+w2;
W3=w+w3;
j=inv(B'*B+s)*(A11'*r1+A22'*r2+A33'*r3);
j1=1/C*inv(B11'*B11+s)*A11'*r1;
j2=1/C*inv(B22'*B22+s)*A22'*r2;
j3=1/C*inv(B33'*B33+s)*A33'*r3;
J1=j1+j;
J2=j2+j;
J3=j3+j;
d1=0;
% make a prediction
for i=(c+1):120
   k=(task1(i,1:o)*W1(1:o,:)+W1(r,:))/norm(W1(1:o,:));
   j=(task1(i,1:o)*J1(1:o,:)+J1(r,:))/norm(J1(1:o,:));
   if(((abs(k)<=abs(j))&task1(i,r)==1)|((abs(k)>abs(j))&task1(i,r)==-1))
       d1=d1+1;
   end
end
      p1= d1/(120-c)*100
      
d2=0;
for i=(c+1):120
   k=(task2(i,1:o)*W2(1:o,:)+W2(r,:))/norm(W2(1:o,:));
   j=(task2(i,1:o)*J2(1:o,:)+J2(r,:))/norm(J2(1:o,:));
   if(((abs(k)<=abs(j))&task2(i,r)==1)|((abs(k)>abs(j))&task2(i,r)==-1))
       d2=d2+1;
   end
end
      p2= d2/(120-c)*100
      
      d3=0;
for i=(c+1):120
   k=(task3(i,1:o)*W3(1:o,:)+W3(r,:))/norm(W3(1:o,:));
   j=(task3(i,1:o)*J3(1:o,:)+J3(r,:))/norm(J3(1:o,:));
   if(((abs(k)<=abs(j))&task3(i,r)==1)|((abs(k)>abs(j))&task3(i,r)==-1))
       d3=d3+1;
   end
end
      p3= d3/(120-c)*100
 %write in the txt.
save('t.txt', 'p1', '-ASCII','-append');
save('t.txt', 'p2', '-ASCII','-append');
save('t.txt', 'p3', '-ASCII','-append');     
       end
end


