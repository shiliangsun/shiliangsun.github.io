% Alternative multi-view med experiment on ionosphere dataset. Note that the range for parameter c is [2^1,2^2,...,2^30].
addpath .\cvx
addpath .\data
cvx_setup;
load ionosphere;
[N,m1]=size(X1);
[qs,qi]=sort(rand(N,1));
X1=X1(qi,:);
X2=X2(qi,:);
y=y(qi,:);
CC=30;
FF=10;
RR=11;

 indices = crossvalind('Kfold',N,FF);
 indices=mod(indices,FF);
for F = 1:FF
	       test = ((indices == mod(F,FF))+(indices == mod(F+1,FF))+(indices == mod(F+2,FF))+(indices == mod(F+3,FF))+(indices == mod(F+4,FF))==1); train = ~test;
		   Test1=X1(test,:);Test2=X2(test,:);
		   Train1=X1(train,:);Train2=X2(train,:);
		   ytrain=y(train);ytest=y(test);		   
		   [n,n1]=size(Train1);
		   [m,m1]=size(Test1);
 	
	u1=10e-15*eye(n,n);
	u2=10e-15*eye(m,n);
	g=-3;
	type=1;
	sigma=1;
	D1=makekernel(Train1,Train1,type,sigma)+u1;
	K1=makekernel(Test1,Train1,type,sigma)+u2;
	D2=makekernel(Train2,Train2,type,sigma)+u1;
	K2=makekernel(Test2,Train2,type,sigma)+u2;
	e=ones(n,1);
	x0=0.5*ones(n,1);
	for c=1:CC
		C=2^(c);
		cvx_quiet(true);
		for rou=1:RR
			Rou=0.1*(rou-1);
			O=zeros(n,1);
			U=C*ones(n,1);
				[lambda,fval,exitflag,output,x]=fmincon(@(lambda) objfun(lambda,C,Rou,n,ytrain,D1,D2),x0,[],[],ytrain',0,O',U'); 
				epsilon=10e-8;
				sv=find(C>lambda>epsilon);
				sv1=find(lambda(sv)>epsilon);
				i_sv=find(lambda(sv1)>epsilon);
				tmp1=(lambda.*ytrain)'*makekernel(Train1,Train1(i_sv,:),type,sigma);
			    ee=ones(length(i_sv),1);
			    bb1=(ee-(1/(C*ee-lambda(i_sv)))')./ytrain(i_sv)-tmp1';
				b1{c}=mean(bb1);
				tmp2=(lambda.*ytrain)'*makekernel(Train2,Train2(i_sv,:),type,sigma);
				bb2=(ee-(1/(C*ee-lambda(i_sv)))')./ytrain(i_sv)-tmp2';
				b2{c}=mean(bb2);
			if(isnan(lambda))
			continue;
			else
			half=floor(length(ytest)/2);
			ypredict1{F,c,rou}=K1*(lambda.*ytrain)+b1{c};
			ypredict2{F,c,rou}=K2*(lambda.*ytrain)+b2{c};
			ypredict3{F,c,rou}=Rou*(K1*(lambda.*ytrain)+b1{c})+(1-Rou)*(K2*(lambda.*ytrain)+b2{c});
			acc1cv(F,c,rou)=accuracy(ytest(1:half),sign(ypredict1{F,c,rou}(1:half)+10e-10));
			acc2cv(F,c,rou)=accuracy(ytest(1:half),sign(ypredict2{F,c,rou}(1:half)+10e-10));
			acc3cv(F,c,rou)=accuracy(ytest(1:half),sign(ypredict3{F,c,rou}(1:half)+10e-10));
			acc1(F,c,rou)=accuracy(ytest(half+1:end),sign(ypredict1{F,c,rou}(half+1:end)+10e-10));
			acc2(F,c,rou)=accuracy(ytest(half+1:end),sign(ypredict2{F,c,rou}(half+1:end)+10e-10));
			acc3(F,c,rou)=accuracy(ytest(half+1:end),sign(ypredict3{F,c,rou}(half+1:end)+10e-10));
			end
		end %rou
		
				fprintf('%d',c);
		fprintf('ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc');
		
	end %c

		fprintf('%d',F);
		fprintf('ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff');

end %F
%Average the results.				
		aaa1=mean(acc1,1);
		aaa1cv=mean(acc1cv,1);
		astd1=std(acc1,0,1);
		bbb1=reshape(aaa1,CC,RR);
		bbb1cv=reshape(aaa1cv,CC,RR);
		bstd1=reshape(astd1,CC,RR);
		
		aaa2=mean(acc2,1);
		aaa2cv=mean(acc2cv,1);
		astd2=std(acc2,0,1);
		bbb2=reshape(aaa2,CC,RR);
		bbb2cv=reshape(aaa2cv,CC,RR);
		bstd2=reshape(astd2,CC,RR);
		
		aaa3=mean(acc3,1);
		aaa3cv=mean(acc3cv,1);
		astd3=std(acc3,0,1);
		bbb3=reshape(aaa3,CC,RR);
		bbb3cv=reshape(aaa3cv,CC,RR);
		bstd3=reshape(astd3,CC,RR);
%select the parameters and obtain the results on the test data set.
for h=1:11
		bestrou1=1;
		bestc1=1;
		best=0;			
			for c=1:CC
				for rou=h:h
					if (bbb1cv(c,rou)>=best)
					bestrou1=rou;
					bestc1=c;
					best=bbb1cv(c,rou);
					end
				end
			end
		bestacc1=bbb1(bestc1,bestrou1);
		std1=bstd1(bestc1,bestrou1);
		
		bestrou2=1;
		bestc2=1;
		best=0;
			for c=1:CC
			for rou=h:h					
					if (bbb2cv(c,rou)>=best)
					bestrou2=rou;
					bestc2=c;
					best=bbb2cv(c,rou);
					end
				end
			end
		bestacc2=bbb2(bestc2,bestrou2);
		std2=bstd2(bestc2,bestrou2);
		
		bestrou3=1;
		bestc3=1;
		best=0;
			for c=1:CC
				for rou=h:h	
					if (bbb3cv(c,rou)>=best)
					bestrou3=rou;
					bestc3=c;
					best=bbb3cv(c,rou);
					end
				end
			end
		bestacc3=bbb3(bestc3,bestrou3);
		std3=bstd3(bestc3,bestrou3);
		
		[f,fi]=max([bestacc1 bestacc2 bestacc3]);  %f indicates the best accuracy. 
		if(fi==1)
		std=std1;
		elseif(fi==2)
		std=std2;
		else
		std=std3;
		end
		ff(h)=f;
		ffstd(h)=std;
	end
	[fff,iii]=max(ff);
	fffstd=ffstd(iii);

  fprintf('\n');
  disp('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');
  fprintf('\n');
  disp('AMVMED');
  fprintf('\n');
  disp([fff,fffstd]);
  fprintf('\n');