Guoqing Chao, Shiliang Sun. Alternative multi-view maximum entropy discrimination. IEEE Transactions on Neural Networks and Learning Systems, 2015.

cvx software package can be downloaded from http://cvxr.com/cvx/download/. As to the setup of cvx, refer to .\cvx\cvx_usrguide.pdf.
data folder includes the ionosphere data.
ainomulviewmed is the program for alternative multi-view med with ionosphere data set.
written by Guoqing Chao, 2013-5-10.
