% This function defines the objective function for AMVMED.
function f = objfun(lambda,C,rou,n,ytrain,D1,D2)
e=ones(n,1);
f = -lambda'*e-e'*log(e-lambda/C)+0.5*rou*(lambda.*ytrain)'*D1*(lambda.*ytrain)+0.5*(1-rou)*(lambda.*ytrain)'*D2*(lambda.*ytrain);
