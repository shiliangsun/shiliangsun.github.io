%funMvLapSVM.m
%Shiliang Sun, 2010-6-25

function [alpha1,alpha2,AccTrainL,AccTrainU]=funMvLapSVM(labeled, unlabeled, r1, r2, r3)

l=length(labeled.y);
u=length(unlabeled.y);

%====================3. Kernel matrix and other realted matrices computation
K1=calckernel('linear',[],[labeled.v1; unlabeled.v1]) + 1;  %0.35 is the same as in experiment_moon.m
K2=calckernel('linear',[],[labeled.v2; unlabeled.v2]) + 1;

bandwidth1=mean(std([labeled.v1; unlabeled.v1],0,1));  bandwidth2=mean(std([labeled.v2; unlabeled.v2],0,1));
L1=laplacianSun2([labeled.v1; unlabeled.v1],6, bandwidth1);         %number of nearest neighbor 6: the same as in experiment_moon.m
L2=laplacianSun2([labeled.v2; unlabeled.v2],6, bandwidth2);

J1=r1*K1+r2*K1*L1*K1+r3*K1*K1; J2=r1*K2+r2*K2*L2*K2+r3*K2*K2;  J1=(J1+J1')/2; J2=(J2+J2')/2;
if rank(J1)<size(J1,1)-0.5
    temp625=max(eig(J1));
    J1=J1+temp625*(1e-5)*eye(size(J1)); %for numerical stability, full rank
end
if rank(J2)<size(J2,1)-0.5
    temp625=max(eig(J2));
    J2=J2+temp625*(1e-5)*eye(size(J2)); %for numerical stability, full rank
end

CholFa=chol(J1); 
InvJ1=CholFa\(CholFa'\eye(size(J1)));
CholFa=chol(J2); 
InvJ2=CholFa\(CholFa'\eye(size(J2)));

M1=2*J1-2*r3*r3*K1*K2*InvJ2*K2*K1; M2=2*J2-2*r3*r3*K2*K1*InvJ1*K1*K2; M1=(M1+M1')/2; M2=(M2+M2')/2; 
if rank(M1)<size(M1,1)-0.5
    temp625=max(eig(M1));
    M1=M1+temp625*(1e-5)*eye(size(M1)); %for numerical stability, full rank
end
temp0707=min(eig(M1));
if temp0707<0
    M1=M1+(-temp0707)*(1+ 1e-5)*eye(size(M1)); %for numerical stability, full rank
end
if rank(M2)<size(M2,1)-0.5
    temp625=max(eig(M2));
    M2=M2+temp625*(1e-5)*eye(size(M2)); %for numerical stability, full rank
end
temp0707=min(eig(M2));
if temp0707<0
    M2=M2+(-temp0707)*(1+ 1e-5)*eye(size(M2)); %for numerical stability, full rank
end

CholFa=chol(M1); 
InvM1=CholFa\(CholFa'\eye(size(M1)));
CholFa=chol(M2); 
InvM2=CholFa\(CholFa'\eye(size(M2)));

%===================4. Quadratic optimization
Y=diag(labeled.y);
Kl1=K1(:,1:l); Kl2=K2(:,1:l); 

A=Y*Kl1'*InvM1*Kl1*Y;  D=Y*Kl2'*InvM2*Kl2*Y;
B=r3*Y*Kl1'*InvJ1*K1*K2*InvM2*Kl2*Y; %C=r3*Y*Kl2'*inv(J2)*K2*K1*inv(M1)*Kl1*Y;
C=B';

H=[A B; C D]; H=(H+H')/2;
f=-ones(2*l,1);
lb=zeros(2*l,1); ub=ones(2*l,1)/(2*l);
[x,fval,exitflag] = quadprog(H,f,[],[],[],[],lb,ub);
lamda1=x(1:l,:);
lamda2=x(l+1:l+l,:);

%===================5. Solving other parameters
Lamda1=Kl1*Y*lamda1; Lamda2=Kl2*Y*lamda2;
alpha1=InvM1*(Lamda1+r3*K1*K2*InvJ2*Lamda2);
alpha2=InvM2*(Lamda2+r3*K2*K1*InvJ1*Lamda1);

%===================6. Accuracies
%--on (labeled + unlabeled) training data
train_f1=K1*alpha1; train_f2=K2*alpha2; train_f12=(train_f1 + train_f2)/2;
train_f1=sign(train_f1); train_f2=sign(train_f2); train_f12=sign(train_f12);
AccTrainL.f1=length(find(abs(labeled.y-train_f1(1:l))<1e-5))/l;
AccTrainL.f2=length(find(abs(labeled.y-train_f2(1:l))<1e-5))/l;
AccTrainL.f12=length(find(abs(labeled.y-train_f12(1:l))<1e-5))/l;

AccTrainU.f1=length(find(abs(unlabeled.y-train_f1(l+1:end))<1e-5))/u;
AccTrainU.f2=length(find(abs(unlabeled.y-train_f2(l+1:end))<1e-5))/u;
AccTrainU.f12=length(find(abs(unlabeled.y-train_f12(l+1:end))<1e-5))/u;