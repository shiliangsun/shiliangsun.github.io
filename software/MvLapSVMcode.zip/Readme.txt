Shiliang Sun. Multi-view Laplacian support vector machines. The 7th International
Conference on Advanced Data Mining and Applications (ADMA), Lecture Notes in
Artificial Intelligence, 2011, 7121: 209-222.

1. MvLapSVM_NBA.m is the main algorithm for MvLapSVM to generate the results in Section 4.2.

2. Some files are modified from previous files provide by other researchers. Thanks go to them.