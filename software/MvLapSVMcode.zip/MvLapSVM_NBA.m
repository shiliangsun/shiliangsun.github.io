%MvLapSVM_TMTL.m
%Shiliang Sun. 2009-5-29, 2010-6-24

clear;
load DataConvRes;
%X, Y

%=================1. Parameter Setting
lpn=[5 5];
l=sum(lpn);     %number of labeled examples
upn=[207 207];
u=sum(upn);     %number of unlabeled examples
vpn=[103 103];
v=sum(vpn);     %# validation set
tpn=[105 105];
t=sum(tpn);     %# test set
regRange=[1e-10 1e-6 1e-4 1e-2 1 10 100];

%=================2. Data division (should be adapted for different data sets)
PosLoc=find(Y==1); NegLoc=find(Y==-1);
for multidiv=1:10 %multiple random divisions
    disp(['***multidiv=' num2str(multidiv) '...***']);
    rand('state',multidiv);
    temp1=randperm(length(PosLoc)); temp2=randperm(length(NegLoc));
    %------labeled data
    IndexL=[PosLoc(temp1(1:lpn(1))); NegLoc(temp2(1:lpn(2)))];
    labeled.v1=X.v1(IndexL,:); labeled.v2=X.v2(IndexL,:);
    labeled.y=Y(IndexL);
    %------unlabeled data
    IndexU=[PosLoc(temp1(lpn(1)+1:lpn(1)+upn(1))); NegLoc(temp2(lpn(2)+1:lpn(2)+upn(2)))];
    unlabeled.v1=X.v1(IndexU,:); unlabeled.v2=X.v2(IndexU,:);
    unlabeled.y=Y(IndexU);
    %------validation data
    IndexV=[PosLoc(temp1(lpn(1)+upn(1)+1:lpn(1)+upn(1)+vpn(1))); NegLoc(temp2(lpn(2)+upn(2)+1:lpn(2)+upn(2)+vpn(2)))];
    validata.v1=X.v1(IndexV,:); validata.v2=X.v2(IndexV,:);
    validata.y=Y(IndexV);
    %------test data
    IndexT=[PosLoc(temp1(lpn(1)+upn(1)+vpn(1)+1:end)); NegLoc(temp2(lpn(2)+upn(2)+vpn(2)+1:end))];
    testdata.v1=X.v1(IndexT,:); testdata.v2=X.v2(IndexT,:);
    testdata.y=Y(IndexT);

    %===================Training with different parameters
    %warning off all;
    numReg=length(regRange);
    AccValidMat.f1=zeros(numReg,numReg,numReg);
    AccValidMat.f2=AccValidMat.f1; AccValidMat.f12=AccValidMat.f1;

    for ii=1:numReg
        r1=regRange(ii);
        for jj=1:numReg
            r2=regRange(jj);
            for kk=1:numReg
                r3=regRange(kk);
                disp(['ii=' num2str(ii) ', jj=' num2str(jj) ', kk=' num2str(kk) '...']);
                [alpha1,alpha2,AccTrainL,AccTrainU]=funMvLapSVM(labeled, unlabeled, r1, r2, r3);
                %------------Accuracy on the validation set
                K1=calckernel('linear',[],[labeled.v1; unlabeled.v1], validata.v1) + 1;  %0.35 is the same as in experiment_moon.m
                K2=calckernel('linear',[],[labeled.v2; unlabeled.v2], validata.v2) + 1;
                vali_f1=K1*alpha1; vali_f2=K2*alpha2; vali_f12=(vali_f1 + vali_f2)/2;
                vali_f1=sign(vali_f1); vali_f2=sign(vali_f2); vali_f12=sign(vali_f12);
                AccValidMat.f1(ii,jj,kk)=sum(abs(validata.y-vali_f1)<1e-5)/length(validata.y);
                AccValidMat.f2(ii,jj,kk)=sum(abs(validata.y-vali_f2)<1e-5)/length(validata.y);
                AccValidMat.f12(ii,jj,kk)=sum(abs(validata.y-vali_f12)<1e-5)/length(validata.y);
                disp([AccValidMat.f1(ii,jj,kk) AccValidMat.f2(ii,jj,kk) AccValidMat.f12(ii,jj,kk)]);
            end
        end
    end

    %===================Select parameters
    AccValidVec.f1=AccValidMat.f1(:); AccValidVec.f2=AccValidMat.f2(:); AccValidVec.f12=AccValidMat.f12(:);
    temp626=[max(AccValidVec.f1) max(AccValidVec.f2) max(AccValidVec.f12)];
    funcInd=find(temp626==max(temp626));
    if length(funcInd)>1.1
        temp626=randperm(length(funcInd));
        funcInd=funcInd(temp626(1));
    end
    switch funcInd
        case 1
            Accuracy(multidiv).f=1;
            Loc.f1=find(AccValidVec.f1==max(AccValidVec.f1));
            if length(Loc.f1)>1.1
                temp626=randperm(length(Loc.f1)); Loc.f1=Loc.f1(temp626(1));
            end
            [ii,jj,kk]=ind2sub(size(AccValidMat.f1),Loc.f1);
        case 2
            Accuracy(multidiv).f=2;
            Loc.f2=find(AccValidVec.f2==max(AccValidVec.f2));
            if length(Loc.f2)>1.1
                temp626=randperm(length(Loc.f2)); Loc.f2=Loc.f2(temp626(1));
            end
            [ii,jj,kk]=ind2sub(size(AccValidMat.f2),Loc.f2);
        case 3
            Accuracy(multidiv).f=3;
            Loc.f12=find(AccValidVec.f12==max(AccValidVec.f12));
            if length(Loc.f12)>1.1
                temp626=randperm(length(Loc.f12)); Loc.f12=Loc.f12(temp626(1));
            end
            [ii,jj,kk]=ind2sub(size(AccValidMat.f12),Loc.f12);
    end

    %========================Train and test with the identified parameter
    disp(['Parameters identified: ii=' num2str(ii) ', jj=' num2str(jj) ', kk=' num2str(kk) '...']);
    r1=regRange(ii); r2=regRange(jj); r3=regRange(kk);
    [alpha1,alpha2,AccTrainL,AccTrainU]=funMvLapSVM(labeled, unlabeled, r1, r2, r3);
    %------------Accuracy on the test set
    K1=calckernel('linear',[],[labeled.v1; unlabeled.v1], testdata.v1) + 1;  %0.35 is the same as in experiment_moon.m
    K2=calckernel('linear',[],[labeled.v2; unlabeled.v2], testdata.v2) + 1;
    test_f1=K1*alpha1; test_f2=K2*alpha2; test_f12=(test_f1 + test_f2)/2;
    test_f1=sign(test_f1); test_f2=sign(test_f2); test_f12=sign(test_f12);

    switch funcInd
        case 1
            Accuracy(multidiv).U=AccTrainU.f1;
            Accuracy(multidiv).T=sum(abs(testdata.y-test_f1)<1e-5)/length(testdata.y);
        case 2
            Accuracy(multidiv).U=AccTrainU.f2;
            Accuracy(multidiv).T=sum(abs(testdata.y-test_f2)<1e-5)/length(testdata.y);
        case 3
            Accuracy(multidiv).U=AccTrainU.f12;
            Accuracy(multidiv).T=sum(abs(testdata.y-test_f12)<1e-5)/length(testdata.y);
    end

    disp([Accuracy(multidiv).f Accuracy(multidiv).U Accuracy(multidiv).T]);
    ParaReg.r1(multidiv)=r1;     ParaReg.r2(multidiv)=r2;    ParaReg.r3(multidiv)=r3;
end

save MvLapSVM_NBA_res Accuracy ParaReg;

disp('OKay.');