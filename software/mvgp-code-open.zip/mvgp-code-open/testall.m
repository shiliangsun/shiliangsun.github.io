clear;
dbstop if error;

load('ionosphere.mat')


N=size(X1,1);
[coeff,score,latent] = pca(X1);
X11=score*coeff';%X12=score;
[coeff,score,latent] = pca(X2);
X21=score*coeff';%X22=score;
 X1=X11;X2=X21;
 
FF=5;
F=1;
indices = crossvalind('Kfold',N,FF);
indices=mod(indices,FF);

res_mvgp1=zeros(5,4);
res_mvgp2=zeros(5,4);
res_svm=zeros(5,3);
res_GP=zeros(5,3);

for F = 1:FF
    test = ((indices == mod(F,FF))+(indices == mod(F+1,FF))==1); 

    train = ~test;
    Test1=X1(test,:);Test2=X2(test,:);  Test=[Test1,Test2];
    Train1=X1(train,:);Train2=X2(train,:); Train=[Train1,Train2];
    ytrain=y(train);ytest=y(test);

    fprintf('%d',F);
    fprintf('nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn');
    fprintf('\n');     

     %MvGP
    [acc,a,b,f]=MvGP1(Train1,Train2,Train,ytrain,Test1,Test2,ytest);
    res_mvgp1(F,:)=[acc,a,b,f];

    [acc,a,b,f]=MvGP2(Train1,Train2,Train,ytrain,Test1,Test2,ytest);
    res_mvgp2(F,:)=[acc,a,b,f];
end





meanres_mvgp1=mean(res_mvgp1(:,1));
stdres_mvgp1=std(res_mvgp1(:,1));

meanres_mvgp2=mean(res_mvgp2(:,1));
stdres_mvgp2=std(res_mvgp2(:,1));

save('ionosphere60.mat','res_mvgp1','res_mvgp2',...
    'meanres_mvgp1','stdres_mvgp1','meanres_mvgp2','stdres_mvgp2');