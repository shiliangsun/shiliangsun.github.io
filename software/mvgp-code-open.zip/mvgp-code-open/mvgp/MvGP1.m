  function [acc,a,b,f]=MvGP1(Train1,Train2,Train,ytrain,Test1,Test2,ytest)
    dbstop if error;
    % This code use scg to minimize objective function w.r.t the log of param
    [N2,d]=size(Train1);
    FF=10;

    indices2 = crossvalind('Kfold',N2,FF);
    indices2=mod(indices2,FF);

    max_a=-1;
    max_b=-1;
    max_p=-1;
    max_f=-1;
    for k=1:FF
        vaild = ((indices2 == mod(k,FF))+(indices2 == mod(k+1,FF))==1);
        tra = ~vaild;
        Tra=Train(tra,:); Vaild=Train(vaild,:);
        Tra1=Tra(:,1:d);
        Tra2=Tra(:,(d+1):end);
        ytra=ytrain(tra); yvaild=ytrain(vaild);
        Vaild1=Vaild(:,1:d);
        Vaild2=Vaild(:,(d+1):end);
        
        initial_param=log(rand(1,6));
        for a=[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]
             for b_gp=[2e-18,2e-12,2e-8,2,2e3,2e8]
     %%           
     
        %        options=zeros(18,1);options(1)=1;options(2)=0.0000001;options(3)=0.0000001;
         %       param=scg('objFun',initial_param,options,'obj_grad',Tra,ytra,a,b,d);

              [param,f,i] = minimize(initial_param,@(pa)(objFunction(pa,Tra,ytra,a,b_gp,d)),-400);


                   meanfunc1 = @meanZero; 
                   likfunc1 = @likGauss; 
                   covfunc1 = @covSEiso;
                   hyp1.cov = [param(1),param(2)];
                   hyp1.mean = [];    
                   hyp1.lik = param(3);

                   meanfunc2 = @meanZero; 
                   likfunc2 = @likGauss; 
                   covfunc2 = @covSEiso;
                   hyp2.cov = [param(4),param(5)];
                   hyp2.mean = []; 
                   hyp2.lik = param(6);

                   [yz1 s1] = gp(hyp1, @infExact, meanfunc1, covfunc1, likfunc1, Tra1, ytra, Vaild1);
                   [yz2 s2] = gp(hyp2, @infExact, meanfunc2, covfunc2, likfunc2, Tra2, ytra, Vaild2);           
                   yz3=a*yz1+(1-a)*yz2;

                   yz1=yz1>=0;yz1=(yz1-0.5)*2;
                   r1=sum(yz1==yvaild)/(size(yvaild,1));
                   yz2=yz2>=0;yz2=(yz2-0.5)*2;
                   r2=sum(yz2==yvaild)/(size(yvaild,1));          
                   yz3=yz3>=0;yz3=(yz3-0.5)*2;
                   r3=sum(yz3==yvaild)/(size(yvaild,1));

                   temp=max([r1,r2,r3]);
                   if temp>max_p
                       if r1>r2
                           if r1>r3
                               max_p=r1;
                               max_f=1;
                           else
                               max_p=r3;
                               max_f=3;
                           end
                       else
                           if r2>r3
                               max_p=r2;
                               max_f=2;
                           else
                               max_p=r3;
                               max_f=3;
                           end
                       end
                       max_a=a;max_b=b_gp;initial_param2=param; 
                   end               
            end
        end
    end


    a=max_a;b_gp=max_b;
    % options=zeros(18,1);options(1)=1;options(2)=eps;options(3)=eps;
    % param=scg('objFun',param,options,'obj_grad',Tra,ytra,a,b,d);
    [param,~,~] = minimize(initial_param2,@(pa)(objFunction(pa,Train, ytrain,a,b_gp,d)),-400);
  
    hyp1.cov = [param(1),param(2)];
    hyp1.lik = param(3);
    hyp2.cov = [param(4),param(5)];
    hyp2.lik = param(6);

    [ztest1 s1] =gp(hyp1, @infExact, meanfunc1, covfunc1, likfunc1, Train1, ytrain, Test1);
    [ztest2 s2] =gp(hyp2, @infExact, meanfunc2, covfunc2, likfunc2, Train2, ytrain, Test2);
    if max_f==1
        ztest=ztest1;
    elseif max_f==2
        ztest=ztest2;
    else 
        ztest=a*ztest1+(1-a)*ztest2;
    end

    ztest=ztest>=0;ztest=(ztest-0.5)*2;
    acc=(sum(ztest==ytest))/(size(ytest,1));
 
    disp([acc,a,b_gp,max_f]);
    b=b_gp;f=max_f;
  end