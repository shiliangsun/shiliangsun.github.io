
This code is based on the framework of GPML by Jack M. Wang. The GPML code by Jack M. Wang can be downloaded in http://www.gaussianprocess.org/gpml/code/matlab/doc/


%%%%%%%%%%%%%%%%%%%%------HOW TO USE----%%%%%%%%%%%%%%%%%%%
1) download the GPML code.
2) execute ��startup.m�� in the GPML code.
3) add the ��data�� folder and ��mvgp�� folder to your path.
4) execute ��testall.m��
5) results for MvGP1, MvGP2 will be saved.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%---DETAILED COMMENTS------%%%%%%%%%%%%%%%%%%%%%%%%%%%

The ��mvgp�� folder has four files: MvGP1, MvGP2, objFunction, and objFunction3.
Your can put your data set in the ��data�� folder.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
written by Qiuyang Liu,2017-01. It is revised from the code of the paper named "Multi-view Regularized Gaussian Processes��.