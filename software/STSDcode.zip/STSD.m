function [ T Z ] = STSD(X, Y, varargin)
%
% Semi-supervised Tangent Space Discriminant Analysis
%
%   [ T Z ] = STSD(X, Y, alpha, beta, rNearest, varScale, reg)
%   Input :
%       X = d * n labeled data matrix.
%           d is the input dimension,
%           n is the number of examples.
%
%       Y = n dimensional vertical vector of class labels
%           (each element takes an integer between 0 and c,
%           where c is the number of classes)
%           0:             unlabeled
%           {1,2, ... ,c}: labeled
%
%       0 <= alpha <= 1 the trade off parameter for the regularizer
%       default: alpha = 0.1
%
%       gamma = the parameter within the tangent based regularizer
%       default: gamma = 1
%
%       rNearest = the number of nearest neighbors examples used to
%       construct the affinity matrix
%       default: rNearest = 7
%
%       varScale = the scale parameter in the heat kernel function 
%       used to construct the affinity matrix
%       default: varScale = 1;
%
%       beta = the trade off parameter for the Tikhonov regularizer
%       default beta =  0.0001
%
%   Output:
%       T: d x mapped_dims transformation matrix (Z = T' * X)
%       Z: mapped_dims x n matrix of data embedding


if nargin < 2, error('Not enough input arguments.'); end

alpha = 0.1; gamma = 1; rNearest = 7; beta = 0.0001; varScale = 1;
if length(varargin) > 0 && isa(varargin{1}, 'double'), alpha = varargin{1}; end
if length(varargin) > 1 && isa(varargin{2}, 'double'), gamma = varargin{2}; end
if length(varargin) > 2 && isa(varargin{3}, 'double'), rNearest = round(varargin{3}); end
if length(varargin) > 3 && isa(varargin{4}, 'double'), varScale = varargin{4}; end
if length(varargin) > 4 && isa(varargin{5}, 'double'), beta = varargin{5}; end

% Statistic the information of data set
[Dims, N] = size(X);
fprintf(1,'STSD running on %d points in %d dimensions\n',N,Dims);
% Centering the data
sampleMean = mean(X,2);
X = (X - repmat(sampleMean,1,N));

Xl = X(:,Y ~= 0);
Yl = Y(Y ~= 0);

Lunique = unique( Yl');  % unique labels
Lnum = length( Lunique ); % number of unique labels
mapped_dims = Lnum;

%% Construct Sb
Hb = zeros(Dims,Lnum);
for i = 1 : Lnum
    c = Lunique(i);
    Xc = Xl(:, Yl == c);
    numC = size(Xc,2);
    
    Hb(:,i) = sqrt(numC) * mean(Xc, 2);
end
Sb = sparse(Hb * Hb');

% Examine the number of embedding dimension
if mapped_dims > Dims
    mapped_dims = Dims;
    warning('Target dimensionality reduced to %d.', mapped_dims);
end

old_ts_dims = mapped_dims;
tsDims = min([mapped_dims (rNearest + 1) Dims]);
if old_ts_dims > tsDims
    warning('Tangent space dimensionality reduced to %d.', tsDims);
end

%% Constuct TSIMR
% STEP1: Compute pairwise distances, find neighbors, and affinity matrix
fprintf(1,'-->Finding %d nearest neighbours.\n',rNearest);

X2 = sum(X.^2,1);
distance = repmat(X2,N,1)+repmat(X2',1,N)-2*(X'*X);

[sorted,index] = sort(distance);
neighborhood = index(2:(1+rNearest),:);
mean_min_dis=mean(sorted(2,:));

W=sparse(N,N);
for ii=1:N
    W(ii,neighborhood(:,ii))=1;
end
nonzeroInd=find(W+W'>0.9);
W(nonzeroInd)=distance(nonzeroInd); clear sorted index distance;
t=varScale*mean_min_dis;
W(nonzeroInd)=exp(-W(nonzeroInd)/t);
[Ro, Co]=find(W);
numnonzero=length(Ro);

% STEP2: Solve for tangent space using local PCA
fprintf(1,'-->Solving for tangent space using local PCA.\n');

TS=cell(N,1);
for ii=1:N
    tempX=X(:,[ii; neighborhood(:,ii)])';
    [coeff, ~, ~] = princomp(tempX);
    TS{ii}=coeff(:,1:tsDims)';
end
clear coeff;

% STEP3: Construct the quadratic form matrix S
fprintf(1,'-->Construct the quadratic form matrix S.\n');

D = sum(W,1);
D = sparse(diag(D));
L = alpha * 2 * (D - W);
LabelIdx = find(Y ~= 0);
for i = 1 : length(LabelIdx)
    L(LabelIdx(i),LabelIdx(i)) = L(LabelIdx(i),LabelIdx(i)) + (1 - alpha);
end
S1= X * L * X';
clear L;

S21=sparse(N, N*tsDims); S22=S21;
B=ones(tsDims,N,N);
for kk=1:N
    B(:,:,kk) = TS{kk}*(X-repmat(X(:,kk),1,N));
end
for ii=1:numnonzero
    tempRow=Ro(ii); tempCol=Co(ii);
    S21(tempRow, tsDims*tempCol-tsDims+1:tsDims*tempCol)...
        =-W(tempRow, tempCol)*B(:,tempRow,tempCol)';
end
S3H=sparse(tsDims*N, tsDims*N);
for ii=1:N
    tempLoc=find(W(ii,:)>eps);
    Fii=sum(repmat(W(ii,tempLoc),tsDims,1).*B(:,tempLoc,ii),2);
    S22(ii,tsDims*ii-tsDims+1:tsDims*ii)=Fii';
    
    Hii=(repmat(W(ii,tempLoc),tsDims,1).*B(:,tempLoc,ii))*B(:,tempLoc,ii)';
    S3H(tsDims*ii-tsDims+1:tsDims*ii,tsDims*ii-tsDims+1:tsDims*ii)=Hii;
end
S2= alpha * (X* (S21+S22));
clear S21 S22;

S31=sparse(tsDims*N, tsDims*N); S32=S31;
A=cell(N,N);
for ii=1:N
    for jj=1:N
        if jj>ii-0.5
            A{ii,jj}=TS{ii}*TS{jj}';
        else
            A{ii,jj}=A{jj,ii}';
        end
    end
end
clear TS;

for ii=1:numnonzero
    tempRow=Ro(ii); tempCol=Co(ii);
    S32(tsDims*tempRow-tsDims+1:tsDims*tempRow, tsDims*tempCol-tsDims+1:tsDims*tempCol)...
        =2*W(tempRow, tempCol)*A{tempRow,tempCol};
end
for ii=1:N
    tempLoc=find(W(ii,:)>eps);
    Ci=D(ii,ii)*eye(tsDims);
    for kk=1:length(tempLoc)
        Ci=Ci+W(ii,tempLoc(kk))*A{ii,tempLoc(kk)}*A{ii,tempLoc(kk)}';
    end
    S31(tsDims*ii-tsDims+1:tsDims*ii,tsDims*ii-tsDims+1:tsDims*ii)=Ci;
end
S3 = alpha * (S3H + gamma*(S31-S32));
clear S3H S31 S32;

S=[S1 S2; S2' S3];
clear S1 S2 S3;
%% Compute the embedding
% Extending Sb
Sb = sparse([Sb sparse(Dims, tsDims * N)]);
Sb = sparse([Sb; sparse(tsDims * N, Dims + tsDims * N)]);

% Tikhonov betaularization
for i = 1 : size(S,1)
    S(i,i) = S(i,i) + beta;
end

Sb = double(Sb);
S = double(S);

Sb = max(Sb,Sb');
S = max(S,S');

fprintf(1,'-->Compute the embedding.\n');
option.disp = 0; option.isreal = 1; option.issym = 1;
% [T, ~] = eigs(Sb, S, mapped_dims, 'LA', option);
[T, ~] = eigs(full(Sb), full(S), mapped_dims, 'LA', option);

% Normalize eigen vector to get consist result
for i = 1 : mapped_dims
    T(:,i) = T(:,i) / norm( T(:,i));
end

% Determine the metric in the embedding space
T = T(1 : Dims, :);

Z = T' * X;

end