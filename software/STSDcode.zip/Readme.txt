--Matlabe code for "Yang Zhou, Shiliang Sun. Semi-supervised tangent space discriminant analysis. Mathematical Problems in Engineering, Special Issue on Machine Learning with Applications to Autonomous Systems, 2015."

--Run Demo_STSD.m to see what happens.
