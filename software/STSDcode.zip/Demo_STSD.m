clear all;

rand('state',0);
randn('state',0);

%%%%%%%%%%%%% Generate the two moon data set
[X,Y]=GD_GenerateData(2,100,2);
P = cvpartition(Y,'Holdout',0.9);
TrainX = X(:, P.training); TrainY = Y(P.training); 
SemiY = Y; SemiY(P.test) = 0;
TestX = X(:, P.test); TestY = Y(P.test);

%%%%%%%%%%%%% Computing STSD solution

% Use 1-NN Classifier based on Euclidean distance
NumNeighbors = 1; Metric = 'euclidean';

alpha = 0.1; beta = 1; rNearest = 7; % Use default parameter setting
[T_STSD ~] = STSD(X, Y, alpha, beta, rNearest);
Z = X'*T_STSD;
Class = knnclassify(Z(P.test,:), Z(P.training,:), Y(P.training), NumNeighbors, Metric);
LossSTSD = sum(Y(P.test)~= Class)/P.TestSize