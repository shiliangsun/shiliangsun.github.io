
1.FILES
    (1. MGPC.m
    This is the main function for MGPC which returns the learned parameters on given training data and the classification result on given test/evaluation data.
    (2. demo_iris.m
    This is the demo file for using MGPC, which performs MGPC on 10 random splits.
    (3. ./Datasets/iris.mat
    This is the data directory..

2.USAGE
    (1. Download minFunc toolkit from https://www.cs.ubc.ca/~schmidtm/Software/minFunc.html.
    (2. Run the script demo_iris.m.

3.INFORMATION
    The source code is reorganized from the code of the paper "Variational Mixtures of Gaussian Processes for Classiﬁcation". This readme file is written by Chen Luo in Apr 2017. 