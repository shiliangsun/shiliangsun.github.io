% function [ ELBO ] = Lqf( fn_parameters, qzi, qrk, qwk, phi_T_xn, TrainY )
function [ ELBO, gradient ] = Lqf( fn_parameters, qzi, qrk, qwk, phi_T_xn, TrainY )

N=length(TrainY);
qfn = reshape(fn_parameters, [N, 2]);
% qfn(:,2) = abs(qfn(:,2));
T=size(phi_T_xn,1);
g_temp = zeros(size(qfn));
g_temp2 = zeros(size(qfn));
ELBO_temp = zeros(T,1);
for jj = 1:T
    
    M = size(phi_T_xn{jj},1);
    phi_k_xn = phi_T_xn{jj};
    Erk = qrk{jj}.a/qrk{jj}.b;
    Ewk_square = (qfn(:,1).^2)+1./(qfn(:,2).^2) - 2*(repmat(qfn(:,1), 1, M).*phi_k_xn')*qwk{jj}.mu;
    temp1 = qzi(jj,:)'.*Ewk_square;
    ELBO_temp(jj) = -1/2*Erk*sum(temp1);
    g_temp(:,1) = g_temp(:,1) + qzi(jj,:)'*Erk.*(qfn(:,1)- (qwk{jj}.mu' * phi_k_xn)');
    g_temp(:,2) = g_temp(:,2) + qzi(jj,:)'*Erk.*abs(qfn(:,2));
end


temp1 = TrainY'./(1./(exp(1/2*TrainY'.*(-2*qfn(:,1)+TrainY'.*(qfn(:,2).^2))))+1);
g_temp(:,1) = -g_temp(:,1) + temp1;
g_temp(:,2) = -g_temp(:,2) - (abs(qfn(:,2)).*temp1.*TrainY')+1./abs(qfn(:,2));

exp_part = exp(1/2 * TrainY'.*(-2 * qfn(:,1)+TrainY'.*(qfn(:,2).^2)));
if isinf(exp_part)
    log_part = 1/2 * TrainY'.*(-2 * qfn(:,1)+TrainY'.*(qfn(:,2).^2));
else
    log_part = log(1+exp_part);
end
ELBO = -1.*(sum(ELBO_temp) + sum( -log_part + 1/2*log(qfn(:,2).^2)));
gradient = -1.*g_temp(:);
end

