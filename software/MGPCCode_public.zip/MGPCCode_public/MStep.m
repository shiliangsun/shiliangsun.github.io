function [ ObjectiveValue, gradient ] = MStep( thetabold, TrainX, ActSet, M, qwk, qrk,qzi,qfn, ii )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
N = size(TrainX, 2);
thetabold_t = thetabold';
d = length(thetabold_t)-2;
pUkpTheta=cell(d+2,1);
pPhi_k_xnpTheta=cell(d+2,1);
A_g=qwk{ii}.Sigma + qwk{ii}.mu*qwk{ii}.mu';
C_g=A_g;
b_g=qrk{ii}.a/qrk{ii}.b;

g=ones(d+2,1);
Mmat=diag(thetabold_t(2:end-1).^(-2));
Mdist=Mdiagonal_distance(TrainX,TrainX(:,ActSet{ii}),Mmat);
phi_k_xn=thetabold_t(1)^2*exp(-(Mdist.^2)/2); phi_k_xn=phi_k_xn';
Uk=phi_k_xn(:,ActSet{ii})+thetabold_t(end)^2*eye(M);
CholFa=chol(Uk); Ukinv=CholFa\(CholFa'\eye(M));
for jj=1:d+2
    if jj==1
        Mdist=Mdist';
        pPhi_k_xnpTheta{jj}=2*thetabold_t(1)*exp(-(Mdist.^2)/2);                       %partial derivative
        pUkpTheta{jj}=pPhi_k_xnpTheta{jj}(:, ActSet{ii});                               %partial derivative
    elseif jj==d+2
        pUkpTheta{jj}=2*thetabold_t(end)*eye(M); %partial derivative
        pPhi_k_xnpTheta{jj}=zeros(M,N);           %partial derivative
    else
        tempx1=TrainX(jj-1,ActSet{ii}); tempx2=TrainX(jj-1,:); tempdis=L2_distance(tempx1,tempx2); tempdis=tempdis.^2;
        pPhi_k_xnpTheta{jj}= phi_k_xn.*tempdis/(thetabold_t(jj)^3);                    %partial derivative
        pUkpTheta{jj}=pPhi_k_xnpTheta{jj}(:,ActSet{ii});                                %partial derivative
    end
    %Solve gradient g
    first2part=trace((Ukinv-A_g)*pUkpTheta{jj});
    %                     lastpart=diag(pPhi_k_xnpTheta{jj}'*C_g*phi_k_xn)-TrainY'.*(pPhi_k_xnpTheta{jj}'*qwk{ii}.mu);
    lastpart=diag(pPhi_k_xnpTheta{jj}'*C_g*phi_k_xn)-qfn(:,1).*(pPhi_k_xnpTheta{jj}'*qwk{ii}.mu);
    lastpart=2*b_g*qzi(ii,:)*lastpart;
    g(jj)=first2part-lastpart;
end
gradient = -g;
n = size(TrainX,2);
% temp = zeros(n,1);
% for jj = 1:n
%     temp(jj) = phi_k_xn(:,jj)'*A_g*phi_k_xn(:,jj)-2*qfn(jj,1)*phi_k_xn(:,jj)'*qwk{ii}.mu;
% end
temp = log(det(Uk))-trace(Uk*A_g)-b_g*sum(qzi(ii,:)'.*(diag(phi_k_xn'*A_g*phi_k_xn)-2*qfn(:,1).*(phi_k_xn'*qwk{ii}.mu)));
ObjectiveValue = -temp;