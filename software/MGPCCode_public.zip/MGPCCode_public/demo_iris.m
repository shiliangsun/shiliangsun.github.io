clear;
addpath(genpath(pwd))

load iris
data = iris.data;
labels = iris.labels;
data = data(51:150,:);
labels = [ones(50,1);-1*ones(50,1)];

dataset_name = 'iris';

%%
T = [2,3,4];
T_k = size(T,2);
K = 10;
rand_state = [1,2,3];
qfvariance = 0.005*2.^[1,2,3,4,5];
hyper_num = size(rand_state,2);
qf_num = size(qfvariance,2);
acc_MGPC_Sigmoid = zeros(K,1);
acc_MGPC_Sigmoid_eval = zeros(T_k,hyper_num,K,qf_num);
loglik_MGPC_Sigmoid = zeros(K,1);
train_ratio = 4;
indices = zeros(K, size(data,1));
for ii = 1:K
    indices(ii,:) = crossvalind('Kfold',size(data,1),10);
end
flag = 0;
for ii = 1:K
    for kk = 1:qf_num
        for t = 1:T_k
            for jj = 1:hyper_num
                train = (indices(ii,:) <= train_ratio);
                test = (indices(ii,:) > train_ratio);
                test = ( test & (indices(ii,:) <= 3+train_ratio));
                evaluation = (~train) & (~test);
                x = data(train,:);
                y = labels(train,:);
                xt = data(test,:);
                yt = labels(test,:);
                xe = data(evaluation,:);
                ye = labels(evaluation,:);
                
                M = round(length(y')/T(t));
                [thetabold, ActSet, ExpertP, TestAcc, ~ ] = MGPC(x',y',xt',yt', T(t) , M, rand_state(jj),qfvariance(kk));
                
                acc_MGPC_Sigmoid_eval(t,jj,ii,kk) = TestAcc;
                temp_ret = sprintf('Round %d--%d--%d--%d finished.', ii,kk,t,jj);
                disp(temp_ret);
            end
        end
    end
end

mean_eval = mean(acc_MGPC_Sigmoid_eval,3);
max_mean_eval = max(mean_eval(:));
[ind1,ind2,ind3,ind4] = ind2sub(size(mean_eval),find(mean_eval==max_mean_eval,1));
for ii = 1:K
    for kk = 1:qf_num(ind4)
        for t = 1:T_k(ind1)
            for jj = 1:hyper_num(ind2)
                
                train = (indices(ii,:) <= train_ratio);
                test = (indices(ii,:) > train_ratio);
                test = ( test & (indices(ii,:) <= 3+train_ratio));
                evaluation = (~train) & (~test);
                x = data(train,:);
                y = labels(train,:);
                xt = data(test,:);
                yt = labels(test,:);
                xe = data(evaluation,:);
                ye = labels(evaluation,:);
                
                M = round(length(y')/T(t));
                [thetabold, ActSet, ExpertP, TestAcc, TestLogLike ] = MGPC(x',y',xt',yt', T(t) , M, rand_state(jj),qfvariance(kk));
                acc_MGPC_Sigmoid(ii) = TestAcc;
                loglik_MGPC_Sigmoid(ii) = TestLogLike;
            end
        end
    end
end
acc_result = sprintf('Averaged test accuracy is %d%%',mean(acc_MGPC_Sigmoid)*100);
disp(acc_result);