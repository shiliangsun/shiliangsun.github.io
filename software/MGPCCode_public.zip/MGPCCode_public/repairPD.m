function KK = repairPD(K)
[v,l]= eig(K);
ll  = l;
dd= det(K);
eps = 10^-10;
KK= K;
while dd<=0
    ll(find(ll<eps))=eps;
    ll = diag(diag(ll));
    KK = v*ll*v'+eye(length(K))*eps;
    KK = (KK+KK')/2;
    nn= sum(sum(abs(KK-K)));
    dd= det(KK);
    eps = eps*10;
end

