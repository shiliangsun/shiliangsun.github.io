%multi-view med experiment on ionosphere dataset. Note that the range for parameter c is [2^0,2^1,...,2^5],
%because the experiment with parameter c from [2^{-5},2^{-4},...,2^{-1}] is invalid. We can find this by experiment.
addpath .\cvx
addpath .\data
load ionosphere;
[N,m1]=size(X1);
[qs,qi]=sort(rand(N,1));
X1=X1(qi,:);
X2=X2(qi,:);
y=y(qi,:);

FF=10;
CC=6;
  for F = 1:FF
 indices = crossvalind('Kfold',N,FF);
 indices=mod(indices,FF);
           test = ((indices == mod(F,FF))+(indices == mod(F+1,FF))+(indices == mod(F+2,FF))+(indices == mod(F+3,FF))+(indices == mod(F+4,FF))+(indices == mod(F+5,FF))+(indices == mod(F+6,FF))+(indices == mod(F+7,FF))+(indices == mod(F+8,FF))==1); train = ~test;
		   Test1=X1(test,:);Test2=X2(test,:);
		   Train1=X1(train,:);Train2=X2(train,:);
		   ytrain=y(train);ytest=y(test);
		   [n,n1]=size(Train1);
		   [m,m1]=size(Test1);
 
	u1=10e-15*eye(n,n);
	u2=10e-15*eye(m,n);
	type=1;
	sigma=1;
	D1=makekernel(Train1,Train1,type,sigma)+u1;
	K1=makekernel(Test1,Train1,type,sigma)+u2;
	D2=makekernel(Train2,Train2,type,sigma)+u1;
	K2=makekernel(Test2,Train2,type,sigma)+u2;
	e=ones(n,1);
	for c=1:CC
		C=2^(c-1);
		O=zeros(n,1);
		cvx_quiet(true);
		cvx_begin
			variable lambda1(n);
			variable lambda2(n);
			maximize(lambda1'*e+lambda2'*e+e'*log(e-(lambda1+lambda2)/C)-0.5*(lambda1.*ytrain)'*D1*(lambda1.*ytrain)-0.5*(lambda2.*ytrain)'*D2*(lambda2.*ytrain));
			lambda1>=O;
			lambda2>=O;
			lambda1+lambda2<=C;
			lambda1'*ytrain==0;
			lambda2'*ytrain==0; 
		cvx_end
			epsilon=10e-8;
			sv=find(C>(lambda1+lambda2)&(lambda1+lambda2)>epsilon);
			sv1=find(lambda1(sv)>epsilon);
			i_sv=find(lambda2(sv1)>epsilon);
			tmp1=(lambda1.*ytrain)'*makekernel(Train1,Train1(i_sv,:),type,sigma);
			ee=ones(length(i_sv),1);
			bb1=(ee-(1/(C*ee-lambda1(i_sv)))')./ytrain(i_sv)-tmp1';
			b1{c}=mean(bb1);
			tmp2=(lambda2.*ytrain)'*makekernel(Train2,Train2(i_sv,:),type,sigma);
			bb2=(ee-(1/(C*ee-lambda2(i_sv)))')./ytrain(i_sv)-tmp2';
			b2{c}=mean(bb2);
		half=floor(length(ytest)/2);
		ypredict1{F,c}=K1*(lambda1.*ytrain)+b1{c};
		ypredict2{F,c}=K2*(lambda2.*ytrain)+b2{c};
		ypredict3{F,c}=0.5*(K1*(lambda1.*ytrain)+b1{c}+K2*(lambda2.*ytrain)+b2{c});
		acc1cv(F,c)=accuracy(ytest(1:half),sign(ypredict1{F,c}(1:half)+10e-10));
		acc2cv(F,c)=accuracy(ytest(1:half),sign(ypredict2{F,c}(1:half)+10e-10));
		acc3cv(F,c)=accuracy(ytest(1:half),sign(ypredict3{F,c}(1:half)+10e-10));
		acc1(F,c)=accuracy(ytest(half+1:end),sign(ypredict1{F,c}(half+1:end)+10e-10));
		acc2(F,c)=accuracy(ytest(half+1:end),sign(ypredict2{F,c}(half+1:end)+10e-10));
		acc3(F,c)=accuracy(ytest(half+1:end),sign(ypredict3{F,c}(half+1:end)+10e-10));
		%med1
			cvx_begin
				variable lambda1(n);
				maximize(lambda1'*e+e'*log(e-lambda1/C)-0.5*(lambda1.*ytrain)'*D1*(lambda1.*ytrain));
				lambda1>=O;
				lambda1<=C;
				lambda1'*ytrain==0;
			cvx_end
			epsilon=10e-8;
			i_sv=find(C>lambda1&lambda1>epsilon);
			tmp=(lambda1.*ytrain)'*makekernel(Train1,Train1(i_sv,:),type,sigma);
			ee=ones(length(i_sv),1);
			bb=(ee-(1/(C*ee-lambda1(i_sv)))')./ytrain(i_sv)-tmp';
			b{c}=mean(bb);
			half=floor(length(ytest)/2);
			ypredict11{F,c}=K1*(lambda1.*ytrain)+b{c};
			acc11cv(F,c)=accuracy(ytest(1:half),sign(ypredict11{F,c}(1:half)+10e-10));
			acc11(F,c)=accuracy(ytest(half+1:end),sign(ypredict11{F,c}(half+1:end)+10e-10));
		%med2
		cvx_begin
			variable lambda2(n);
			maximize(lambda2'*e+e'*log(e-lambda2/C)-0.5*(lambda2.*ytrain)'*D2*(lambda2.*ytrain));
			lambda2>=O;
			lambda2<=C;
			lambda2'*ytrain==0;
		cvx_end
			epsilon=10e-8;
			i_sv=find(C>lambda2&lambda2>epsilon);
			tmp=(lambda2.*ytrain)'*makekernel(Train2,Train2(i_sv,:),type,sigma);
			ee=ones(length(i_sv),1);
			bb=(ee-(1/(C*ee-lambda2(i_sv)))')./ytrain(i_sv)-tmp';
			b{c}=mean(bb);
			half=floor(length(ytest)/2);
		ypredict22{F,c}=K2*(lambda2.*ytrain)+b{c};
		acc22cv(F,c)=accuracy(ytest(1:half),sign(ypredict22{F,c}(1:half)+10e-10));
		acc22(F,c)=accuracy(ytest(half+1:end),sign(ypredict22{F,c}(half+1:end)+10e-10));		
	end

		fprintf('%d',F);
		fprintf('nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn');
		fprintf('\n');

end
		averacc1cv=mean(acc1cv);
		averacc2cv=mean(acc2cv);
		averacc3cv=mean(acc3cv);
		averacc11cv=mean(acc11cv);
		averacc22cv=mean(acc22cv);
		
		averacc1=mean(acc1);
		std1=std(acc1,1);
		averacc2=mean(acc2);
		std2=std(acc2,1);
		averacc3=mean(acc3);
		std3=std(acc3,1);
		averacc11=mean(acc11);
		std11=std(acc11,1);		
		averacc22=mean(acc22);
		std22=std(acc22,1);		
		
		[fav1cv,i1cv]=max(averacc1cv);
		[fav2cv,i2cv]=max(averacc2cv);
		[fav3cv,i3cv]=max(averacc3cv);
		fav1=averacc1(i1cv);
		fav2=averacc2(i2cv);
		fav3=averacc3(i3cv);
		[f,fi]=max([fav1 fav2 fav3]);
		if(fi==1)
		std=std1(i1cv);
		elseif(fi==2)
		std=std2(i2cv);
		else
		std=std3(i3cv);
		end
%med1
		[fav11cv,i1cv]=max(averacc11cv);
		fav11=averacc11(i1cv);
		std1=std11(i1cv);
%med2	
		[fav22cv,i2cv]=max(averacc22cv);
		fav22=averacc22(i2cv);
		std2=std22(i2cv);
		
  fprintf('\n');
  disp('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');
  fprintf('\n');
  disp('MVMED');
  fprintf('\n');
  disp([f,std]);
  fprintf('\n');
  disp('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');
  fprintf('\n');
  disp('single-view MED1');
  fprintf('\n');
  disp([fav11,std1]);
  fprintf('\n');
  disp('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');
  fprintf('\n');
  disp('single-view MED2');
  fprintf('\n');
  disp([fav22,std2]);
  fprintf('\n');
  disp('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');