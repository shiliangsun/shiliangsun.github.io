Shiliang Sun, Guoqing Chao. Multi-view maximum entropy discrimination.
Proceedings of the 23rd International Joint Conference on Artificial Intelligence
(IJCAI), 2013. 1706-1712.

cvx software package can be downloaded from http://cvxr.com/cvx/download/. As to the setup of cvx, refer to .\cvx\cvx_usrguide.pdf.
data folder includes the ionosphere data.
inomulviewmed is the program for multi-view med with ionosphere data set.
written by Guoqing Chao, 2012-10-9.
