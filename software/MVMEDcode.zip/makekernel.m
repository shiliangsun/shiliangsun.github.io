function [K] = makekernel(x,y,type,sigma)
%type=1,siga=1; linear kernel
%type=1,siga!=1; polynomial kernel
%type!=1;  rbf kernel
if type==1 
   if sigma==1
     K = x*y';           
   else
     K = 1+x*y';
     K = K.^sigma;
   end
else 
[row] = size(x,1);
[row1,col]=size(y);

if col==1

   K = (x.^2)*ones(1,row1) + ones(row,1)*(y.^2)' -2*x*y';

else
   K = (sum((x.^2)')'*ones(1,row1) + ones(row,1)*sum((y.^2)') -2*x*y');

end
   K = exp( -K/(sigma^2));
end 
