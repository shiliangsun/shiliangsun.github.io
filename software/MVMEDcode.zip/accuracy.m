%d is the true label��c is the predicted label;
function [acc]=accuracy(d,c);
	MODE = all(size(d)==size(c)) & all(all((c==1) | (c==-1)));
if ~MODE
	display('illegal input!');
end
	[x,y]=size(d);
	right=0;
	for i=1:x
		if(d(i)==c(i))
			right=right+1;
		end
	end
	acc=right/x;