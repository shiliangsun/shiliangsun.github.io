Shiliang Sun. Tangent space intrinsic manifold regularization for data representation. Proceedings of the 1st IEEE China Summit and International Conference on Signal and Information Processing (ChinaSIP), 2013. 179-183.


1. Swissroll_TSIMR.m
The code to generate Fig.1 in the above paper.

2. Swissroll_TSIMR_Hole.m
The code to generate Fig.2(a) and Fig.2(b) in the above paper.

