% TSIMR ALGORITHM (using K nearest neighbors)
%
% [Y] = lle(X,K,m)
%
% X = data as d x k matrix (d = dimensionality, k = #points)
% K = number of neighbors
% m = max embedding dimensionality
% Y = embedding as m x k matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Y] = TSIMR(X,K,m,gammaPar)

varscalepar=1; %useful to calculate the heat-kernel weight.
[Dim,N] = size(X);
fprintf(1,'TSIMR running on %d points in %d dimensions\n',N,Dim);


% STEP1: COMPUTE PAIRWISE DISTANCES, FIND NEIGHBORS, Compute weight matrix
fprintf(1,'-->Finding %d nearest neighbours.\n',K);

X2 = sum(X.^2,1);
distance = repmat(X2,N,1)+repmat(X2',1,N)-2*X'*X;

[sorted,index] = sort(distance);
neighborhood = index(2:(1+K),:);
mean_min_dis=mean(sorted(2,:));

W=sparse(N,N);
for ii=1:N
    W(ii,neighborhood(:,ii))=1;
end
nonzeroInd=find(W+W'>0.9);
W(nonzeroInd)=distance(nonzeroInd); clear sorted index distance;
t=varscalepar*mean_min_dis;
W(nonzeroInd)=exp(-W(nonzeroInd)/t);
[Ro, Co]=find(W);
numnonzero=length(Ro);
% STEP2: Solve for tangent space using local PCA
fprintf(1,'-->Solving for tangent space using local PCA.\n');

TS=cell(N,1);
for ii=1:N
    tempX=X(:,[ii; neighborhood(:,ii)])';
    [coeff, score, latent] = princomp(tempX);
    TS{ii}=coeff(:,1:m)';
end

% STEP3: Construct the quadratic form matrix S
fprintf(1,'-->Construct the quadratic form matrix S.\n');

D = sum(W,1);
D = sparse(diag(D));
S1= 2*(D-W);

S21=sparse(N, N*m); S22=S21;
B=ones(m,N,N);
for kk=1:N
    B(:,:,kk) = TS{kk}*(X-repmat(X(:,kk),1,N));
end
for ii=1:numnonzero
    tempRow=Ro(ii); tempCol=Co(ii);
    S21(tempRow, m*tempCol-m+1:m*tempCol)=-W(tempRow, tempCol)*B(:,tempRow,tempCol)';
end
S3H=sparse(m*N, m*N);
for ii=1:N
    tempLoc=find(W(ii,:)>eps);
    Fii=sum(repmat(W(ii,tempLoc),m,1).*B(:,tempLoc,ii),2);
    S22(ii,m*ii-m+1:m*ii)=Fii';
    
    Hii=(repmat(W(ii,tempLoc),m,1).*B(:,tempLoc,ii))*B(:,tempLoc,ii)';
    S3H(m*ii-m+1:m*ii,m*ii-m+1:m*ii)=Hii;
end
S2= S21+S22;
clear S21 S22;

S31=sparse(m*N, m*N); S32=S31;
A=cell(N,N);
for ii=1:N
    for jj=1:N
        if jj>ii-0.5
            A{ii,jj}=TS{ii}*TS{jj}';
        else
            A{ii,jj}=A{jj,ii}';
        end
    end
end

for ii=1:numnonzero
    tempRow=Ro(ii); tempCol=Co(ii);
    S32(m*tempRow-m+1:m*tempRow, m*tempCol-m+1:m*tempCol)=2*W(tempRow, tempCol)*A{tempRow,tempCol};
end
for ii=1:N
    tempLoc=find(W(ii,:)>eps);
    Ci=D(ii,ii)*eye(m);
    for kk=1:length(tempLoc)
        Ci=Ci+W(ii,tempLoc(kk))*A{ii,tempLoc(kk)}*A{ii,tempLoc(kk)}';
    end
    S31(m*ii-m+1:m*ii,m*ii-m+1:m*ii)=Ci;
end
S3=S3H + gammaPar*(S31-S32);
clear S3H S31 S32;

S=[S1 S2; S2' S3];
clear S1 S2 S3;

% STEP4: Sparse eigen-decomposition, CALCULATION OF EMBEDDING
fprintf(1,'-->Sparse eigen-decomposition. Computing embedding.\n');

options.disp = 0; options.isreal = 1; options.issym = 1; 
[Y,eigenvals] = eigs(S,m+1,0,options);
Y = Y(:,2:m+1)'*sqrt(N); % bottom evect is [1,1,1,1...] with eval 0. Why??

fprintf(1,'TSIMR embedding Done.\n');
